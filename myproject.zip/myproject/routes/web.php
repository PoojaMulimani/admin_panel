<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('product', function () {
    return view('product');
});

Route::get('image-gallery', 'ImageGalleryController@index');
Route::post('image-gallery', 'ImageGalleryController@upload');
Route::delete('image-gallery/{id}', 'ImageGalleryController@destroy');
//Route::post('image-gallery/{id}', 'ImageGalleryController@edit');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::post('product', 'ImageGalleryController@upload');
Route::delete('product/{id}', 'ImageGalleryController@destroy');
Route::get('product', 'ImageGalleryController@indexfile');